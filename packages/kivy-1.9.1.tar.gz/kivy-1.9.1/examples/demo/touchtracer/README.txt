Touchtracer
===========

Touchtracer is a simple example to draw lines under every touches detected
on your hardware.

Android
-------

You can copy/paste this directory into /sdcard/kivy/touchtracer in your
android device.

